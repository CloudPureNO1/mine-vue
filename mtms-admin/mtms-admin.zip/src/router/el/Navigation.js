import elNavMenu from '@/components/el/ELNavMenu'

let routes=[
    {path : '/navMenu',name : 'NavMenu', component : elNavMenu}
]

export default routes;