import ELCollapse from '@/components/el/Collapse'
let routers = [
    {path : '/elCollapse' , name : '/ELCollapse' , component : ELCollapse}
];
export default routers;