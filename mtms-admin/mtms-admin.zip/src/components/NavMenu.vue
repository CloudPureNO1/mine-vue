<template>
    <div>
        <TopMenu></TopMenu>
        <LeftMenu></LeftMenu>
    </div>
</template>
<script>
import LeftMenu from '@/components/LeftMenu'
import TopMenu from '@/components/TopMenu'
export default {
    data(){
        return{
            
        }
    },
    components:{
        LeftMenu,
        TopMenu
    }
}
</script>

 